#!/usr/bin/env python3
"""ComfyUI API-format workflow client (stdlib only): replace widget inputs, POST /prompt, poll /history, fetch outputs via /view."""
import argparse, http.client, json, os, subprocess, sys, time, urllib.error, urllib.parse, urllib.request, uuid
from pathlib import Path

OK, FAIL, USAGE, TIMEOUT, CONN = 0, 1, 2, 3, 4
LOOPBACK = {"127.0.0.1", "localhost"}


class ClientError(Exception):
    def __init__(self, msg, code=FAIL, body=None):
        super().__init__(msg)
        self.code, self.body = code, body


def err(*a):
    print(*a, file=sys.stderr, flush=True)


def describe(body):
    try:
        d = json.loads(body)
    except (TypeError, ValueError):
        return None
    out = {k: d[k] for k in ("error", "node_errors") if isinstance(d, dict) and d.get(k)}
    return json.dumps(out)[:3000] if out else None


def exec_error(st):
    for m in st.get("messages", []):
        if isinstance(m, list) and len(m) == 2 and m[0] == "execution_error":
            d = m[1]
            return f"node {d.get('node_id')} ({d.get('node_type')}): {d.get('exception_type')}: {d.get('exception_message')}"
    return json.dumps(st)[:1000]


class GpuMeter:
    """Sample the selected device during one run; figures are device-wide."""
    def __init__(self, index):
        self.index = index
        self.samples = []

    def sample(self):
        try:
            out = subprocess.run(
                ['nvidia-smi', '-i', str(self.index),
                 '--query-gpu=name,memory.used,utilization.gpu', '--format=csv,noheader,nounits'],
                capture_output=True, text=True, timeout=3, check=True,
            ).stdout.strip().split(',')
            if len(out) >= 3:
                self.samples.append((out[0].strip(), int(out[1].strip()), int(out[2].strip())))
        except (OSError, subprocess.SubprocessError, ValueError):
            pass

    def summary(self):
        if not self.samples:
            return {'index': self.index, 'samples': 0}
        baseline = self.samples[0][1]
        return {'index': self.index, 'name': self.samples[0][0], 'samples': len(self.samples),
                'baseline_used_mib': baseline,
                'peak_used_mib': max(row[1] for row in self.samples),
                'peak_util_percent': max(row[2] for row in self.samples),
                'avg_util_percent': round(sum(row[2] for row in self.samples) / len(self.samples))}


class Comfy:
    def __init__(self, host, port, http_timeout):
        self.base, self.timeout = f"http://{host}:{port}", http_timeout
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    def req(self, path, payload=None, raw=False):
        data = None if payload is None else json.dumps(payload).encode()
        r = urllib.request.Request(self.base + path, data=data, headers={"Content-Type": "application/json"} if data else {})
        try:
            with self.opener.open(r, timeout=self.timeout) as resp:
                body = resp.read()
        except urllib.error.HTTPError as e:
            text = e.read().decode("utf-8", "replace")
            raise ClientError(f"HTTP {e.code} on {path}: {text[:2000]}", FAIL, text) from None
        except (urllib.error.URLError, http.client.HTTPException, OSError) as e:
            raise ClientError(f"cannot reach {self.base}{path}: {e}", CONN) from None
        if raw:
            return body
        try:
            return json.loads(body or b"null")
        except ValueError:
            raise ClientError(f"non-JSON response on {path}: {body[:200]!r}") from None

    def submit(self, wf, client_id):
        try:
            res = self.req("/prompt", {"prompt": wf, "client_id": client_id})
        except ClientError as e:
            raise ClientError(f"prompt rejected: {describe(e.body) or e}", e.code) from None
        if not isinstance(res, dict) or not res.get("prompt_id"):
            raise ClientError(f"no prompt_id in response: {res}")
        if res.get("node_errors"):
            raise ClientError(f"node errors: {json.dumps(res['node_errors'])[:2000]}")
        return res["prompt_id"]

    def wait(self, pid, timeout, poll, meter=None):
        t0, fails = time.monotonic(), 0
        while True:
            if meter:
                meter.sample()
            try:
                entry = (self.req("/history/" + urllib.parse.quote(pid)) or {}).get(pid)
                fails = 0
            except ClientError as e:
                fails += 1
                if e.code != CONN or fails >= 5:
                    raise
                entry = None
            if entry:
                st = entry.get("status") or {}
                if st.get("status_str") == "error":
                    raise ClientError("execution failed: " + exec_error(st))
                if st.get("completed") or st.get("status_str") == "success":
                    return entry
            if time.monotonic() - t0 > timeout:
                raise ClientError(f"timeout after {timeout}s waiting for {pid}", TIMEOUT)
            time.sleep(poll)

    def download_outputs(self, outputs, out_dir):
        files = []
        for nid, out in (outputs or {}).items():
            for kind, items in out.items():
                for it in items if isinstance(items, list) else []:
                    if not (isinstance(it, dict) and it.get("filename")):
                        continue
                    sub, typ = it.get("subfolder", ""), it.get("type", "output")
                    q = urllib.parse.urlencode({"filename": it["filename"], "subfolder": sub, "type": typ})
                    dest = out_dir / f"{nid}_{Path(it['filename']).name}"
                    out_dir.mkdir(parents=True, exist_ok=True)
                    tmp = dest.with_name(dest.name + ".part")
                    tmp.write_bytes(self.req("/view?" + q, raw=True))
                    os.replace(tmp, dest)
                    files.append({"node": nid, "kind": kind, "filename": it["filename"], "subfolder": sub, "type": typ, "local_path": str(dest)})
        return files


def load_workflow(path):
    try:
        wf = json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        raise ClientError(f"cannot read workflow {path}: {e}", USAGE) from None
    if isinstance(wf, dict) and isinstance(wf.get("prompt"), dict) and "class_type" not in wf["prompt"]:
        wf = wf["prompt"]
    if isinstance(wf, dict) and "nodes" in wf and "links" in wf:
        raise ClientError("UI-format workflow; export it with 'Save (API Format)' / 'Export (API)'", USAGE)
    if not isinstance(wf, dict) or not wf or not all(isinstance(n, dict) and "class_type" in n for n in wf.values()):
        raise ClientError("not an API-format workflow (expected {node_id: {class_type, inputs}})", USAGE)
    return wf


def collect_replacements(a):
    reps = []
    if a.params:
        try:
            p = json.loads(Path(a.params).read_text(encoding="utf-8"))
        except (OSError, ValueError) as e:
            raise ClientError(f"bad --params: {e}", USAGE) from None
        for k, v in p.items():
            if isinstance(v, dict) and "." not in k:
                reps += [(f"{k}.{i}", x) for i, x in v.items()]
            else:
                reps.append((k, v))
    for kind, items in (("str", a.set), ("json", a.set_json), ("file", a.set_file)):
        for s in items:
            k, sep, v = s.partition("=")
            if not sep:
                raise ClientError(f"bad replacement {s!r}; use NODE.INPUT=VALUE", USAGE)
            try:
                v = json.loads(v) if kind == "json" else Path(v).read_text(encoding="utf-8") if kind == "file" else v
            except (OSError, ValueError) as e:
                raise ClientError(f"bad value for {k}: {e}", USAGE) from None
            reps.append((k, v))
    return reps


def apply_replacements(wf, reps, allow_new):
    for key, val in reps:
        node, _, inp = key.partition(".")
        n = wf.get(node)
        if n is None or not inp:
            raise ClientError(f"bad target {key!r}; node ids: {sorted(wf)}", USAGE)
        ins = n.setdefault("inputs", {})
        if inp not in ins and not allow_new:
            raise ClientError(f"node {node} ({n['class_type']}) has no input {inp!r}; inputs: {sorted(ins)}", USAGE)
        cur = ins.get(inp)
        if isinstance(cur, list) and len(cur) == 2 and isinstance(cur[0], str):
            raise ClientError(f"{key} is a link to node {cur[0]}; edit the upstream node instead", USAGE)
        ins[inp] = val


def cmd_health(a, c, ctx):
    print(json.dumps(c.req("/system_stats"), indent=2))
    return OK


def cmd_nodes(a, c, ctx):
    if a.show:
        print(json.dumps(c.req("/object_info/" + urllib.parse.quote(a.show)), indent=2))
    else:
        print(json.dumps(sorted(n for n in c.req("/object_info") if a.filter.lower() in n.lower()), indent=2))
    return OK


def cmd_run(a, c, ctx):
    wf = load_workflow(a.workflow)
    apply_replacements(wf, collect_replacements(a), a.allow_new_input)
    if a.dry_run:
        print(json.dumps(wf, indent=2, ensure_ascii=False))
        return OK
    t0 = time.monotonic()
    meter = GpuMeter(a.track_gpu_index) if a.track_gpu_index is not None else None
    if meter:
        meter.sample()
    pid = ctx["prompt_id"] = c.submit(wf, a.client_id or str(uuid.uuid4()))
    err(f"submitted prompt_id={pid}")
    try:
        entry = c.wait(pid, a.timeout, a.poll, meter)
    except ClientError as e:
        if e.code == TIMEOUT and a.interrupt_on_timeout:
            try:
                c.req("/interrupt", {})
            except ClientError:
                pass
        raise
    files = [] if a.no_download else c.download_outputs(entry.get("outputs"), Path(a.out_dir) / pid)
    if meter:
        meter.sample()
    print(json.dumps({"ok": True, "prompt_id": pid, "elapsed_s": round(time.monotonic() - t0, 1),
                      "gpu_usage": meter.summary() if meter else None,
                      "outputs": entry.get("outputs"), "files": files}, ensure_ascii=False, indent=2))
    return OK


def build_parser():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--host", default=os.environ.get("COMFY_HOST", "127.0.0.1"))
    ap.add_argument("--port", type=int, default=int(os.environ.get("COMFY_PORT", "8288")))
    ap.add_argument("--allow-remote-host", action="store_true", help="permit a non-loopback host (not recommended)")
    ap.add_argument("--http-timeout", type=float, default=60, help="per-request timeout in seconds")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("health", help="GET /system_stats").set_defaults(func=cmd_health)
    n = sub.add_parser("nodes", help="list node classes (GET /object_info)")
    n.add_argument("--filter", default="", help="case-insensitive substring")
    n.add_argument("--show", metavar="CLASS", help="print the full spec of one node class")
    n.set_defaults(func=cmd_nodes)
    r = sub.add_parser("run", help="patch + submit an API-format workflow and wait for outputs")
    r.add_argument("workflow", help="API-format workflow JSON")
    r.add_argument("--set", action="append", default=[], metavar="NODE.INPUT=TEXT", help="string replacement")
    r.add_argument("--set-json", action="append", default=[], metavar="NODE.INPUT=JSON", help="typed replacement (numbers, bools, lists)")
    r.add_argument("--set-file", action="append", default=[], metavar="NODE.INPUT=PATH", help="replace with file text (e.g. lyrics)")
    r.add_argument("--params", help="JSON file: {'NODE.INPUT': value} or {'NODE': {'INPUT': value}}")
    r.add_argument("--allow-new-input", action="store_true", help="allow adding inputs the node does not already have")
    r.add_argument("--out-dir", default="./comfy_out", help="downloaded outputs go to OUT_DIR/<prompt_id>/")
    r.add_argument("--no-download", action="store_true")
    r.add_argument("--timeout", type=float, default=1800, help="seconds to wait for completion")
    r.add_argument("--poll", type=float, default=2)
    r.add_argument("--track-gpu-index", type=int, choices=range(16), help="sample this GPU's device-wide memory and utilization")
    r.add_argument("--interrupt-on-timeout", action="store_true")
    r.add_argument("--client-id")
    r.add_argument("--dry-run", action="store_true", help="print the patched workflow and exit")
    r.set_defaults(func=cmd_run)
    return ap


def main():
    a, ctx = build_parser().parse_args(), {}
    try:
        if a.host not in LOOPBACK and not a.allow_remote_host:
            raise ClientError(f"refusing non-loopback host {a.host}; use --allow-remote-host to override", USAGE)
        return a.func(a, Comfy(a.host, a.port, a.http_timeout), ctx)
    except ClientError as e:
        err(f"error: {e}")
        print(json.dumps({"ok": False, "error": str(e), **ctx}, ensure_ascii=False))
        return e.code


if __name__ == "__main__":
    sys.exit(main())
