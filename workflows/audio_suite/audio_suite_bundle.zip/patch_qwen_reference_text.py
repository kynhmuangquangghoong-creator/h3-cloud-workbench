"""Enable optional transcript-conditioned Qwen3-TTS cloning on the independent audio node.

Run once with the same local Python runtime used by audio_task.py. Keeps remote
pre-change backups beside the two node files; never touches the H3 workspace.
"""
import sys
from pathlib import Path, PurePosixPath

sys.path.insert(0, str(Path(__file__).resolve().parent))

from audio_task import connect

ROOT = PurePosixPath('/home/xuliangliang/workspaces/audio-ai/comfyui/custom_nodes/Qwen3-TTS')
REPLACEMENTS = {
    'nodes.py': [
        ('            "reference_audio": ("AUDIO",),\n        }}',
         '            "reference_audio": ("AUDIO",),\n        }, "optional": {\n'
         '            "reference_text": ("STRING", {"multiline": True, "default": ""}),\n        }}'),
        ('def generate(self, text: str, language: str, seed: int, reference_audio: dict[str, Any]):',
         'def generate(self, text: str, language: str, seed: int, reference_audio: dict[str, Any], reference_text: str = ""):'),
        ('"seed": seed, "reference_path": str(reference),',
         '"seed": seed, "reference_path": str(reference),\n                "reference_text": reference_text.strip(),'),
    ],
    'worker.py': [
        ('        prompt = model.create_voice_clone_prompt(\n            ref_audio=str(reference), x_vector_only_mode=True\n        )',
         '        reference_text = str(request.get("reference_text") or "").strip()\n'
         '        prompt = model.create_voice_clone_prompt(\n'
         '            ref_audio=str(reference), ref_text=reference_text or None,\n'
         '            x_vector_only_mode=not bool(reference_text)\n        )'),
    ],
}


def main():
    client = connect()
    try:
        with client.open_sftp() as sftp:
            changes = []
            for name, pairs in REPLACEMENTS.items():
                target = str(ROOT / name)
                with sftp.open(target, 'rb') as f:
                    original = f.read()
                updated = original.decode('utf-8')
                if name == 'nodes.py':
                    duplicate = '                "reference_text": reference_text.strip(),\n' * 2
                    updated = updated.replace(duplicate, '                "reference_text": reference_text.strip(),\n')
                for before, after in pairs:
                    if after in updated:
                        continue
                    if before in updated:
                        updated = updated.replace(before, after, 1)
                    else:
                        raise RuntimeError(f'{name}: expected source fragment missing')
                new = updated.encode('utf-8')
                if new != original:
                    changes.append((target, original, new, sftp.stat(target).st_mode))
            for target, original, new, mode in changes:
                backup = target + '.before-reference-text-20261024'
                try:
                    sftp.stat(backup)
                except FileNotFoundError:
                    with sftp.open(backup, 'wb') as f:
                        f.write(original)
                temp = target + '.reference-text.tmp'
                with sftp.open(temp, 'wb') as f:
                    f.write(new)
                sftp.chmod(temp, mode)
                sftp.posix_rename(temp, target)
                print('patched', target)
            if not changes:
                print('already patched')
    finally:
        client.close()


if __name__ == '__main__':
    main()
