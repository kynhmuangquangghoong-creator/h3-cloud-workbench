#!/usr/bin/env bash
set -euo pipefail
root=/home/xuliangliang/workspaces/audio-ai
models="$root/comfyui/models"
base='https://hf-mirror.com/Comfy-Org/stable-audio-3/resolve/main'
mkdir -p "$models/checkpoints" "$models/text_encoders" "$root/logs" "$root/state"

download_verified() {
  local rel=$1 expected=$2
  local dest="$models/$rel"
  local partial="$dest.part"
  if [[ -f "$dest" ]] && echo "$expected  $dest" | sha256sum -c --status; then
    echo "[$(date -Is)] verified cached $rel"
    return
  fi
  echo "[$(date -Is)] downloading $rel on GPU node via HF mirror"
  curl --fail --location --retry 6 --retry-all-errors --retry-delay 5 --connect-timeout 15 \
    --continue-at - --output "$partial" "$base/$rel"
  echo "$expected  $partial" | sha256sum -c --status
  mv -f "$partial" "$dest"
  echo "[$(date -Is)] SHA256 verified $rel"
}

download_verified 'checkpoints/stable_audio_3_small_sfx.safetensors' \
  'ed9cf1b6172f1a8c2921a9560c21109ff3239524563ced9dce6dcdef41e2f515'
download_verified 'text_encoders/t5gemma_b_b_ul2.safetensors' \
  '1e1eba25be8872edb0d3c6335c6658fd6388e7b14b60da6e454e404cfcd8150e'

"$root/venv/bin/python" - <<'PY'
import fcntl, json, os, time
from pathlib import Path
root = Path('/home/xuliangliang/workspaces/audio-ai')
state = root / 'state'
models = root / 'comfyui/models'
items = [
    ('checkpoints/stable_audio_3_small_sfx.safetensors', 'ed9cf1b6172f1a8c2921a9560c21109ff3239524563ced9dce6dcdef41e2f515'),
    ('text_encoders/t5gemma_b_b_ul2.safetensors', '1e1eba25be8872edb0d3c6335c6658fd6388e7b14b60da6e454e404cfcd8150e'),
]
with (state / 'model_provenance.lock').open('a+b') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    path = state / 'model_provenance.json'
    data = json.loads(path.read_text()) if path.exists() else {}
    now = time.strftime('%Y-%m-%dT%H:%M:%S%z')
    files = []
    for rel, sha in items:
        st = (models / rel).stat()
        files.append(dict(path=rel, size=st.st_size, mtime_ns=st.st_mtime_ns, sha256=sha,
                          source_path=rel, remote_sha256=sha))
    data['stable_audio3_small_sfx'] = dict(id='stable_audio3_small_sfx', status='complete',
        type='gated', source='hf-mirror.com (Comfy-Org official repack)', repo='Comfy-Org/stable-audio-3',
        revision='main', downloaded_at=now, updated_at=now, files=files,
        note='User confirmed authorized access; exact SHA256 matched public Comfy-Org file metadata.')
    tmp = path.with_suffix('.tmp')
    tmp.write_text(json.dumps(data, indent=2, sort_keys=True))
    os.replace(tmp, path)
print('Stable Audio 3 SFX provenance recorded')
PY
