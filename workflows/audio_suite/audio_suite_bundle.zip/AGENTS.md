# audio-ai 工作区（远程 4×RTX 5090 节点）

> 状态：独立环境已运行，ACE-Step、TTS、ASR、Demucs、YuE2、Stable Audio 3 均已生成测试产物。下述状态以远端日志和产物为准。本文件不含任何凭据。

## 1. 隔离与目录（$ROOT = /home/xuliangliang/workspaces/audio-ai）

- 与 H3 工作区完全独立：独立 venv、独立 ComfyUI 克隆、独立端口；严禁向 H3 的 venv 安装任何东西。
- 所有模型下载只在本节点执行。ACE/Qwen/YuE2 经 ModelScope；Stable Audio 3 使用 hf-mirror.com 传输 Comfy-Org 官方打包文件并核对 SHA256。禁止本地下载后上传。

| 路径 | 用途 |
|---|---|
| $ROOT/bootstrap.sh | 建 venv / 安装依赖 / 显式启停 ComfyUI |
| $ROOT/download_models.py | 模型下载器（清单驱动，记录 SHA256） |
| $ROOT/download_stable_audio.sh | 经国内 HF 镜像下载 Stable Audio 3 SFX + T5Gemma，并核对 Comfy-Org 官方 SHA256 |
| $ROOT/comfy_client.py | ComfyUI /prompt 命令行客户端（仅标准库） |
| $ROOT/comfyui | ComfyUI 克隆，固定 commit 7cebca52227c63b4180ceed448cbd7ad22903b6d |
| $ROOT/venv | 独立 Python 3.10 环境（torch cu130） |
| $ROOT/comfyui/models | 模型根；ACE 与 YuE2 使用 ComfyUI 标准子目录，Qwen3-TTS 在 qwen-voice/，ASR 在 Qwen3-ASR/ |
| $ROOT/workflows | API 格式工作流 JSON（Codex 测试通过后放入） |
| $ROOT/inputs, outputs, tmp, user | ComfyUI 输入/输出/临时/用户目录 |
| $ROOT/logs/comfyui.log | 服务日志 |
| $ROOT/state | versions.json、pip-freeze.txt、torch-constraints.txt、model_provenance.json、comfyui.pid/.gpu |

## 2. 能力矩阵

| 能力 | 模型 | 来源 | 集成方式 | 测试状态 |
|---|---|---|---|---|
| 音乐生成 | ACE-Step 1.5 XL SFT / XL Turbo，0.6B+4B 编码器，ace_1.5_vae | ModelScope Comfy-Org/ace_step_1.5_ComfyUI_files | ComfyUI 内置节点 comfy_extras/nodes_ace.py | SFT、Turbo 各生成一段 12 秒 FLAC 音频 |
| TTS | Qwen3-TTS-12Hz-1.7B Base / VoiceDesign + Tokenizer | ModelScope Qwen/* | ComfyUI-Qwen3-TTS 节点，节点自己的隔离依赖层 | VoiceDesign、Base 声音克隆均已各产出 WAV；Tokenizer 已下载并记录 |
| ASR | Qwen3-ASR-1.7B-hf | ModelScope Qwen/Qwen3-ASR-1.7B-hf | ComfyUI-QwenASR 节点；原版 1.7B 不与当前节点互换 | 已转写 TTS 样例，内容正确 |
| 音效 | Stable Audio 3 Small SFX + T5Gemma 编码器 | Comfy-Org/stable-audio-3 的公开 ComfyUI 打包权重，经 hf-mirror.com 传输并与官方 SHA256 核对 | ComfyUI 内置 CheckpointLoaderSimple + CLIPLoader | 权重已验证；已产出 5 秒 FLAC 音效 |
| 分轨 | Demucs htdemucs | demucs 官方运行时下载 | 第三方节点；`patch_demucs_compat.py` 避免旧节点对系统 FFmpeg 依赖 | 已从 TTS 样例保存人声、贝斯、鼓、其他四条 FLAC |
| 歌曲生成/翻唱 | YuE2-3B ComfyUI checkpoint + SheetSage2 音频编码器 | ModelScope Comfy-Org/Yue2；官方独立推理包另需 m-a-p/YuE2-Vae | ComfyUI 内置 nodes_yue2.py | 文本到音乐、参考音频转 ABC 并生成翻唱均已产出 FLAC |

## 3. 生命周期（服务仅绑定 127.0.0.1:8288，不自动启动）

```
bash $ROOT/bootstrap.sh setup          # 幂等；可重复执行
bash $ROOT/bootstrap.sh status         # 进程 + 各 GPU 显存
bash $ROOT/bootstrap.sh start <gpu>    # 必须显式指定单卡；空闲显存 < MIN_FREE_MIB(默认 20000) 时拒绝启动(退出码 3)
bash $ROOT/bootstrap.sh stop
```

- start 设置 CUDA_DEVICE_ORDER=PCI_BUS_ID 与 CUDA_VISIBLE_DEVICES=<gpu>（序号与 nvidia-smi 一致）和 HF_HUB_OFFLINE=1。
- 端口可用 AUDIO_AI_PORT 覆盖；客户端用 COMFY_PORT / --port。
- 第三方节点装入 $ROOT/comfyui/custom_nodes，须先审查依赖。Qwen3-TTS 使用节点自己的隔离依赖层；其他节点只用 $ROOT/venv 安装，并保持 torch-constraints.txt 约束。

## 4. 模型下载（必须在本节点运行）

```
PY=$ROOT/venv/bin/python
$PY $ROOT/download_models.py status
$PY $ROOT/download_models.py download --dry-run
$PY $ROOT/download_models.py download                     # 默认集：ACE、Qwen3 TTS/ASR、YuE2；Stable Audio 已验证文件保持 complete，未授权/缺文件则 blocked
$ROOT/download_stable_audio.sh                              # 仅用户接受原模型许可后运行，下载并校验 Comfy-Org 打包权重
$PY $ROOT/download_models.py ls-repo Comfy-Org/Yue2         # 核对远端真实文件名
$PY $ROOT/download_models.py download --only yue2_comfy
$PY $ROOT/download_models.py download --only demucs_htdemucs   # demucs 装好后才可用
```

- 幂等可续传；已完成文件按 size+mtime 跳过（--verify 重算 SHA256，--force 重下）。校验失败的文件改名为 .corrupt。
- 出处与 SHA256/大小记录在 $ROOT/state/model_provenance.json。
- 磁盘余量不足（所需 + 10 GiB）时拒绝下载。
- ACE 官方蓝图同时使用 qwen_0.6b_ace15 与 qwen_4b_ace15；两者均在下载清单，0.6B 已就位。
- Stable Audio 3 Small SFX：用户已确认接受原模型访问条款。Comfy-Org 官方 ComfyUI 打包仓库公开提供 SFX checkpoint 与 T5Gemma；通过 hf-mirror.com 传输，脚本对照官方文件页 SHA256 校验。GGUF 转换包不用于此工作流。

## 5. 调用 API（comfy_client.py，仅标准库，默认 127.0.0.1:8288，绕过环境代理）

本机优先使用全局 `$gpu-audio-workbench` Skill 的统一入口 `E:\Apps\audio-workspace\audio_task.py`。它可按九种模式选工作流、上传本机参考音频，并将输出复制到 `runs/<mode>/<prompt-id>`。示例：

```powershell
& 'E:\CodexData\tools\migration-runtime\python\python.exe' -B 'E:\Apps\audio-workspace\audio_task.py' list
& 'E:\CodexData\tools\migration-runtime\python\python.exe' -B 'E:\Apps\audio-workspace\audio_task.py' status
& 'E:\CodexData\tools\migration-runtime\python\python.exe' -B 'E:\Apps\audio-workspace\audio_task.py' run stems --input-audio 'E:\Apps\audio-workspace\samples\qwen3_voice_design.wav'
```

`audio_task.py list` 列出 `ace-sft`、`ace-turbo`、`tts-design`、`tts-clone`、`asr`、`stems`、`yue2-music`、`yue2-cover`、`sfx`。`run --help` 显示参数；`--dry-run` 不接触远端。已实测从本机上传参考音频并取回四轨、ASR 文本，以及提交提示词取回音效。

- `yue2-music --plan-abc` 可先由 YuE2 的 `YuE2GenerateABC` 节点规划原创旋律与和弦，再交给 `YuE2GenerateMusic` 渲染；默认仍直接按文字生成。该选项不会强制锁定提示词中的拍号或乐器，成品须试听核对。2026-10-24 的原创歌曲试验使用 `lyrics/unsteady.original.en.txt` 和 `--plan-abc`，任务 ID `ebaf96f2888c4cdea53106ea87c06897`，65 秒 FLAC 位于 `runs/yue2-music/b0b95925-b4c3-4287-93ad-f6ecb6c5d6b3/7_yue2_music_00003.flac`。
- 为确保开头有清晰的锡哨笛主旋律，`inspection/compose_whistle_intro.py` 使用 `assets/tin-whistle/neild101-255835-hq-preview.mp3` 中的单个 CC0 延音样本演奏原创旋律，铺极轻钢琴并与上述 YuE2 歌曲渐变衔接；来源许可见 `assets/tin-whistle/SOURCE.md`。产物为 `runs/yue2-music/whistle-intro-20261024/unsteady_whistle_intro.flac`（77.3 秒）。这一阶段是本地音频编曲，不消耗 GPU，源 YuE2 任务的 GPU 记录保留在原任务中。重新生成命令：`C:\Users\Administrator.LAPTOP-GL2SIF73\AppData\Local\Programs\Python\Python310\python.exe inspection\compose_whistle_intro.py --song runs\yue2-music\b0b95925-b4c3-4287-93ad-f6ecb6c5d6b3\7_yue2_music_00003.flac --sample assets\tin-whistle\neild101-255835-hq-preview.mp3 --output runs\yue2-music\whistle-intro-20261024\unsteady_whistle_intro.flac`（在本项目目录执行）。

- 每次 `run` 在本机 `state/tasks/<run-id>.json` 记录执行中、完成或失败；既有 `runs/<mode>/<prompt-id>` 产物可由本机 GPU 工作台 `http://127.0.0.1:5098` 的“ComfyUI → 音频任务记录”回填查看与播放。音频任务仍使用独立的远端 ComfyUI 队列，视频任务队列不会显示它们。
- 工作台音频任务行有“保存到本地”：单个 WAV/FLAC/MP3/TXT 弹出 Windows 另存为窗口，分轨等多文件任务选择文件夹；确认后从 `runs` 复制并核对 SHA-256，原产物保留。另存去向记在 `state/saved_audio.json`，可在任务行“打开文件夹”查看。示例长句另存于 `E:\Apps\audio-workspace\saved\kakashi_15m08-15m26_long_clone.wav`。
- 新任务记录模型、语言、种子、参考文件、运行 GPU、生成耗时；远端 `comfy_client.py --track-gpu-index` 每约 2 秒采样一次所选 GPU 的设备显存与利用率，展示设备显存峰值和平均负载。这些是设备级数据，若同卡有其他进程则不能当成单任务独占量。旧任务未采样的指标在页面显示“未记录/未采样”，不可从产物推算。
- 音频服务默认可与其他进程共用所选 GPU，启动时只检查剩余显存（默认至少 20000 MiB），任务提交仍可能因并发负载发生显存不足或变慢。仅需要排他运行时，在 `audio_task.py run` 增加 `--require-idle-gpu`。这与 H3 视频工作流的独占 GPU 入队策略不同；独立任务队列不等于独占显卡。
- `tts-clone --reference-text '参考音频的准确转写'` 启用 Qwen3-TTS 的 ICL 参考台词模式；省略时使用仅说话人向量模式。远端节点改动由本机 `patch_qwen_reference_text.py` 幂等部署，原文件备份为 `.before-reference-text-20261024`。改动只作用于音频 ComfyUI 的 Qwen3-TTS 节点，更新后须重启独立音频服务。
- 2026-10-24 的《Naruto-010》16:27–16:34 参考音频克隆“我嘞个豆”测试：仅说话人向量模式可识别目标同音句，但用户反馈声线不相似；ICL 日语参考台词模式的中文识别为“瓦雷古姆”，发音未通过。两者均不是经用户认可的成品；不要将 ASR 准确率当成声线相似度。
- 后续在同一视频中选用卡卡西 15:08–15:26 连续独白：本机参考音源 `E:\Apps\audio-workspace\reference\kakashi_15m08s-15m26s_raw.wav`，18 秒；日语 ASR 可连续识别该段讲解。Qwen3-TTS Base 使用该原声（不用分轨清理版）生成 12.88 秒中文长句，输出 `E:\Apps\audio-workspace\runs\tts-clone\381808f2-e266-4800-a131-21be138a7cc1\3_qwen3_voice_clone.wav`。目标文本为“我嘞个豆，这次的训练还真不简单。先别急着往上冲，稳住查克拉，找到自己的节奏。失败了也没关系，记住刚才的感觉，再试一次。” 中文 ASR 完整识别，首句写成同音“我勒个豆”；声线相似度尚待用户试听确认。短句版位于 `runs\tts-clone\b3973369-44fa-40be-b8e4-97789f9dc167`。

直接调用远端 `comfy_client.py` 仍可用于节点级调试：

```
C="python3 $ROOT/comfy_client.py"
$C health
$C nodes --filter ace
$C run $ROOT/workflows/tts_voice_design.api.json --set 1.text='你好' --out-dir $ROOT/outputs/client
$C run $ROOT/workflows/tts_voice_clone.api.json --set 2.text='你好' --out-dir $ROOT/outputs/client
$C run $ROOT/workflows/asr_from_tts.api.json --out-dir $ROOT/outputs/client
$C run $ROOT/workflows/demucs_vocals.api.json --out-dir $ROOT/outputs/client
$C run $ROOT/workflows/demucs_stems.api.json --out-dir $ROOT/outputs/client
$C run $ROOT/workflows/yue2_text_to_music.api.json --set 2.style='bright pop' --out-dir $ROOT/outputs/client
$C run $ROOT/workflows/yue2_cover.api.json --set 5.style='warm acoustic pop' --out-dir $ROOT/outputs/client
$C run $ROOT/workflows/ace15_xl_sft.api.json --set 5.tags='acoustic folk' --out-dir $ROOT/outputs/client
$C run $ROOT/workflows/ace15_xl_turbo.api.json --set 5.tags='acoustic folk' --out-dir $ROOT/outputs/client
$C run $ROOT/workflows/stable_audio3_sfx.api.json --set 3.text='A heavy door slams shut' --out-dir $ROOT/outputs/client
$C run $ROOT/workflows/yue2_text_to_music.api.json --set-file 2.lyrics=/path/lyrics.txt --set-json 2.seed=42 --out-dir $ROOT/outputs/client
```

- 工作流必须是 API 格式（Save (API Format)）；UI 格式会被拒绝。替换目标为 NODE_ID.INPUT，仅限已存在的标量 widget 输入（链接输入拒绝；--allow-new-input 才可新增）。
- 提交 /prompt → 轮询 /history/<id> → /view 下载到 OUT_DIR/<prompt_id>/；stdout 为 JSON（ok、prompt_id、outputs、files），日志在 stderr。
- 退出码：0 成功，1 执行/校验失败，2 用法错误，3 超时（--timeout，可 --interrupt-on-timeout），4 无法连接。
- 非回环 host 需 --allow-remote-host；不要对外暴露服务。
- 本机通过 `remote_exec.py` 调用远端程序；上例 `tts-test.wav` 与 `yue2-reference.flac` 是已放在远端 ComfyUI input 目录的测试音频，替换时需先把参考音频放入该目录。
- 验证产物在远端 `$ROOT/outputs/test/`，详细运行记录在 `$ROOT/logs/*-test.log`。下载记录写入 `$ROOT/state/model_provenance.json` 并显示在本机 GPU 工作台“下载记录”中。
- 本机 `E:\Apps\audio-workspace\fetch_samples.py` 仅复制已知的小体积测试音频到 `E:\Apps\audio-workspace\samples` 供试听，不复制模型权重。运行：`E:\CodexData\tools\migration-runtime\python\python.exe E:\Apps\audio-workspace\fetch_samples.py`。

## 6. 限制

- 4 张 5090 各约 32GB；显存占用随其他任务变化，启动前检查空闲显存，一次只在一张卡上启动。
- 不得改动 H3 工作区；不得写入凭据、SSH 信息或密码。
- Stability AI 原仓库 gated；用户已确认获访问权限。GPU 直连 huggingface.co 不可达；Comfy-Org 公开打包权重通过 hf-mirror.com 可达，按官方哈希验证。

## 7. 测试清单

- [x] setup 成功，Torch 2.13.0+cu130，CUDA 可用；`uv pip check` 通过
- [x] 显式在 GPU 1 启动，health 返回 200，仅监听 127.0.0.1:8288
- [x] download 默认集完成，model_provenance.json 含 SHA256（官方 YuE2 独立推理包是可选项，未下载）
- [x] ACE-Step 1.5 XL SFT 与 Turbo 工作流各出一段 12 秒音频
- [x] Qwen3-TTS VoiceDesign、Qwen3-ASR 节点安装并各跑通一次
- [x] Qwen3-TTS Base 声音克隆已从参考音频产出 WAV
- [x] YuE2 文本到音乐、SheetSage2 音频参考编码、翻唱工作流均跑通
- [x] Demucs htdemucs 四轨分离跑通；兼容补丁在 `$ROOT/patch_demucs_compat.py`
- [x] Stable Audio 3 Small SFX：用户已确认授权；Comfy-Org 权重 SHA256 校验通过，5 秒音效测试通过
- [x] 已通过的工作流存入 $ROOT/workflows，并更新第 2 节测试状态

## 8. 已验证产物（$ROOT/outputs/test）

| 工作流 | 产物 | 媒体信息 |
|---|---|---|
| ace15_xl_sft.api.json | ace15_sft_00001.flac | 12 秒、48 kHz、立体声 |
| ace15_xl_turbo.api.json | ace15_turbo_00001.flac | 12 秒、48 kHz、立体声 |
| tts_voice_design.api.json | qwen3_voice_design.wav | 2.8 秒、24 kHz、单声道 |
| tts_voice_clone.api.json | qwen3_voice_clone.wav | 4.0 秒、24 kHz、单声道 |
| asr_from_tts.api.json | qwen3_asr_00001.txt | `你好，这是音频工作区的测试语音。` |
| demucs_vocals.api.json | demucs_vocals_00001.flac | 2.8 秒、44.1 kHz、立体声 |
| demucs_stems.api.json | demucs_vocals_00002.flac、demucs_bass_00001.flac、demucs_drums_00001.flac、demucs_other_00001.flac | 四轨，2.8 秒、44.1 kHz |
| yue2_text_to_music.api.json | yue2_music_00001.flac | 12 秒、48 kHz、立体声 |
| yue2_cover.api.json | yue2_cover_00001.flac + yue2_cover_abc_00001.txt | 参考音频转 ABC 后生成翻唱 |
| stable_audio3_sfx.api.json | stable_audio3_sfx_00001.flac | 5.02 秒、44.1 kHz、立体声 |

ComfyUI `/free` 可卸载测试后缓存的模型，保持服务运行并归还显存：`curl -X POST -H 'Content-Type: application/json' -d '{"unload_models":true,"free_memory":true}' http://127.0.0.1:8288/free`。2026-10-24 测试后已执行，GPU 1 空闲约 20 GiB；显存是动态值，后续运行前重新检查。
