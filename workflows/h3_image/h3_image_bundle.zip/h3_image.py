"""Image-only H3 parameters. No ComfyUI/video fields or batch execution."""
import math
import secrets

MODEL = 'MiniMax-H3-Image'
PRESETS = {'square_2k': (2048, 2048), 'uhd': (3840, 2160), 'native_wide': (5472, 3072)}
PARAMETER_KEYS = {'mode', 'preset', 'width', 'height', 'seed', 'n'}


def parameters(data):
    if not isinstance(data, dict) or set(data) - PARAMETER_KEYS:
        raise ValueError('图片生成参数格式不正确或包含不支持的参数。')
    if data.get('mode', 'image') != 'image':
        raise ValueError('请选择图片任务模式。')
    preset = data.get('preset', 'square_2k')
    if not isinstance(preset, str) or preset not in {*PRESETS, 'custom'}:
        raise ValueError('请选择有效的图片尺寸预设。')
    default = PRESETS.get(preset, (None, None))
    width, height = data.get('width', default[0]), data.get('height', default[1])
    if any(type(v) is not int or v <= 0 for v in (width, height)):
        raise ValueError('图片宽高需为正整数。')
    if preset in PRESETS and (width, height) != PRESETS[preset]:
        raise ValueError('宽高与图片尺寸预设不一致，请选择自定义尺寸。')
    # UHD is the sole unaligned output: generate 3840x2176 and center-crop 8+8 rows.
    if preset != 'uhd' and (width % 32 or height % 32):
        raise ValueError('自定义图片宽高须为 32 的倍数。')
    if not 655_360 <= width * height <= 20_000_000:
        raise ValueError('图片面积需在 655360–20000000 像素之间。')
    if not 1 / 3 <= width / height <= 3:
        raise ValueError('图片比例需在 1:3–3:1 之间。')
    seed = data.get('seed', -1)
    if (isinstance(seed, bool) or not isinstance(seed, (int, float)) or not math.isfinite(seed)
            or int(seed) != seed or not -1 <= seed <= 2**53 - 1):
        raise ValueError('种子需为 -1 或有效非负整数。')
    if type(data.get('n', 1)) is not int or data.get('n', 1) != 1:
        raise ValueError('图片任务每次仅生成 1 张。')
    return {'mode': 'image', 'preset': preset, 'width': width, 'height': height,
            'seed': secrets.randbelow(2**53) if seed == -1 else int(seed), 'n': 1,
            'model': MODEL, 'gpu_count': 1,
            'generation_width': width, 'generation_height': 2176 if preset == 'uhd' else height}
