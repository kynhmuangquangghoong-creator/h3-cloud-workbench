"""Remote-only H3 image adapter. Reuses the installed, idle-expiring service.

No process is terminated here. Cancelling an in-flight HTTP request waits for it
to finish, discards its response, and releases only this request's lease.
"""
import base64
import hashlib
import importlib.util
import io
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.request

import h3_image
from h3_remote_worker import UsageRecorder, atomic, digest

ROOT = Path('/home/xuliangliang/workspaces/h3-test')
SERVICE = Path('/home/xuliangliang/apps/h3image')


class Cancelled(Exception):
    pass


def safe(path, parent):
    if parent.resolve() != parent or path.resolve() != path or not path.is_relative_to(parent):
        raise ValueError('图片任务目录或文件存在异常链接。')
    return path


def request_data(folder):
    folder = safe(Path(folder), ROOT / 'jobs')
    req = json.loads(safe(folder / 'request.json', folder).read_text(encoding='utf-8'))
    if not re.fullmatch('[0-9a-f]{32}', folder.name) or req.get('id') != folder.name or not req.get('run_token'):
        raise ValueError('图片任务身份不正确。')
    p = h3_image.parameters({k: v for k, v in req['params'].items() if k in h3_image.PARAMETER_KEYS})
    if p != req['params'] or not isinstance(req.get('prompt'), str) or not req['prompt'].strip() or len(req['prompt']) > 40000:
        raise ValueError('图片任务参数或提示词已变化。')
    if req.get('execution_mode', 'serial') != 'serial' or req.get('batch_items'):
        raise ValueError('图片任务不支持批次。')
    return req


def verified_inputs(folder, req):
    from PIL import Image
    assets = req.get('media', [])
    if not isinstance(assets, list) or len(assets) > 16:
        raise ValueError('最多使用 16 张参考图。')
    paths = []
    for index, item in enumerate(assets):
        name = item.get('file', '')
        if (item.get('kind') != 'image' or item.get('role') != 'ref_image_' + str(index)
                or not re.fullmatch(r'[0-9a-f]{32}\.(png|jpg|jpeg|webp)', name)):
            raise ValueError('参考图格式或顺序不正确。')
        path = safe(folder / 'assets' / name, folder)
        if not path.is_file() or path.stat().st_size != item.get('size') or digest(path) != item.get('sha256'):
            raise ValueError('参考图校验失败。')
        with Image.open(path) as image:
            if image.format not in ('PNG', 'JPEG', 'WEBP') or image.width * image.height > 32_000_000:
                raise ValueError('参考图格式不支持或超过 3200 万像素。')
            image.verify()
        paths.append(path)
    return paths


def prepare_job(folder):
    req = request_data(folder)
    verified_inputs(folder, req)
    output = safe(folder / 'output', folder)
    output.mkdir(exist_ok=True)
    atomic(safe(folder / 'prepared.json', folder), {'id': req['id'], 'token': req['run_token'],
           'request_sha256': digest(folder / 'request.json'), 'prepared_at': time.time()})
    return {'prepared': True, 'id': req['id']}


def load_control():
    # Installed application code only; never import a local user script or connection data.
    path = safe(SERVICE / 'h3_remote.py', SERVICE)
    spec = importlib.util.spec_from_file_location('workbench_h3_image_service', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    if module.ROOT != SERVICE or module.PORT != 30083:
        raise RuntimeError('H3 图片服务部署路径或端口不匹配。')
    return module


def inventory():
    """Fail closed on missing/invalid GPU or compute-process information."""
    def query(fields):
        return subprocess.run(['nvidia-smi', fields, '--format=csv,noheader,nounits'],
                              capture_output=True, text=True, check=True, timeout=15).stdout.splitlines()
    processes = {}
    for line in query('--query-compute-apps=gpu_uuid,pid'):
        if not line.strip():
            continue
        uuid, pid = map(str.strip, line.split(','))
        pid = int(pid)
        if not uuid.startswith('GPU-') or pid <= 0:
            raise RuntimeError('显卡进程信息不可用。')
        processes.setdefault(uuid, set()).add(pid)
    cards = []
    for line in query('--query-gpu=index,uuid,memory.used'):
        index, uuid, memory = map(str.strip, line.split(','))
        memory = float(memory)
        if not uuid.startswith('GPU-') or not math.isfinite(memory) or memory < 0:
            raise RuntimeError('显卡显存信息不可用。')
        cards.append({'index': int(index), 'uuid': uuid, 'memory_used_mib': memory,
                      'pids': processes.get(uuid, set())})
    if not cards or len({c['uuid'] for c in cards}) != len(cards):
        raise RuntimeError('显卡清单不可用。')
    return cards


def descendant(pid, parent):
    """Use the current process ancestry; a shared username is never ownership."""
    seen = set()
    while pid > 1 and pid not in seen:
        if pid == parent:
            return True
        seen.add(pid)
        try:
            pid = int(Path('/proc/%d/stat' % pid).read_text().rsplit(')', 1)[1].split()[1])
        except (OSError, ValueError, IndexError):
            return False
    return False


def service_card(control, state, cards, require_healthy=True):
    pid = state.get('service_pid')
    if (not pid or not state.get('service_identity') or (require_healthy and not state.get('healthy')) or not state.get('supervisor_alive') or
            control.identity(pid) != state.get('service_identity')):
        raise RuntimeError('图片服务进程身份未确认。')
    selected = str(state.get('devices', ''))
    card = next((g for g in cards if str(g['index']) == selected), None)
    if card is None or any(not descendant(p, pid) for p in card['pids']):
        raise RuntimeError('图片服务显卡存在其他计算进程，等待释放。')
    return {'index': card['index'], 'uuid': card['uuid']}


def acquire_service(control, publish, check_cancel, observe=None):
    starting_since = None
    while True:
        check_cancel()
        state = control.status()
        cards = inventory()
        if state.get('supervisor_alive'):
            if state.get('healthy'):
                try:
                    return service_card(control, state, cards)
                except RuntimeError as error:
                    publish(status='waiting', stage=str(error))
            else:
                if observe and state.get('service_identity'):
                    try:
                        observe(service_card(control, state, cards, require_healthy=False))
                    except RuntimeError:
                        pass  # Foreign processes must never become this task's usage record.
                if starting_since is None:
                    starting_since = time.monotonic()
                if time.monotonic() - starting_since > 1800:
                    raise RuntimeError('H3 图片服务启动等待超过 30 分钟，请检查服务。')
                publish(status='waiting', stage='等待 H3 图片服务启动')
        else:
            starting_since = None
            # The installed supervisor repeats this check immediately before launch.
            if any(c['memory_used_mib'] < 128 and not c['pids'] for c in cards):
                try:
                    starting = control.start()
                    selected = next((c for c in cards if str(c['index']) == str(starting.get('devices', ''))), None)
                    if observe and selected:
                        observe({'index': selected['index'], 'uuid': selected['uuid']})
                except RuntimeError as error:
                    if 'GPU' not in str(error):
                        raise RuntimeError('H3 图片服务启动失败：' + str(error)[:300]) from None
            else:
                publish(status='waiting', stage='排队中 · 等待无计算进程且显存低于 128 MiB 的显卡')
        time.sleep(2)


def image_request(control, req, images):
    p = req['params']
    fields = {'prompt': req['prompt'], 'size': '%dx%d' % (p['generation_width'], p['generation_height']),
              'seed': p['seed'], 'generator_device': 'cpu', 'response_format': 'b64_json',
              'output_format': 'png', 'min_generation_area': 2048**2}
    if images:
        body, mime = control.multipart(fields, images)
        endpoint = '/v1/images/edits'
    else:
        body, mime = json.dumps(fields).encode('utf-8'), 'application/json'
        endpoint = '/v1/images/generations'
    # Loopback only; bypass any inherited HTTP proxy configuration.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    request = urllib.request.Request('http://127.0.0.1:30083' + endpoint, body, {'Content-Type': mime})
    try:
        with opener.open(request, timeout=3600) as response:
            payload = json.load(response)
    except urllib.error.HTTPError as error:
        raise RuntimeError('H3 图片服务请求失败，HTTP %d。' % error.code) from None
    data = payload.get('data')
    if not isinstance(data, list) or len(data) != 1:
        raise ValueError('图片服务返回结果数量不正确。')
    raw = base64.b64decode(data[0]['b64_json'], validate=True)
    if not raw.startswith(b'\x89PNG\r\n\x1a\n'):
        raise ValueError('图片服务未返回 PNG。')
    from PIL import Image
    with Image.open(io.BytesIO(raw)) as image:
        if image.size != (p['generation_width'], p['generation_height']):
            raise ValueError('图片输出尺寸不匹配。')
        image.load()
        if p['preset'] == 'uhd':
            image = image.crop((0, 8, 3840, 2168))
        result = io.BytesIO()
        image.save(result, 'PNG', compress_level=6)
    return result.getvalue()


def run(folder):
    import fcntl
    folder = Path(folder)
    req = request_data(folder)
    state = {'id': req['id'], 'token': req['run_token'], 'pid': os.getpid(),
             'status': 'waiting', 'stage': '等待图片服务', 'progress': None}
    publish_lock = threading.RLock()
    stop = threading.Event()
    usage = None
    started = generated = None

    def publish(**values):
        with publish_lock:
            if state['status'] in ('completed', 'failed', 'cancelled'):
                return
            state.update(values, updated_at=time.time())
            if started is not None:
                state['execution_seconds'] = round(time.monotonic() - started, 2)
            if usage is not None:
                state['usage'] = usage.summary()
            atomic(safe(folder / 'state.json', folder), state)

    def check_cancel():
        cancel = safe(folder / 'cancel.json', folder)
        if cancel.exists() and json.loads(cancel.read_text()).get('token') == req['run_token']:
            raise Cancelled()

    lease = SERVICE / 'active.flag'
    owns_lease = False
    thread = None
    lock = None

    def begin_usage(card):
        nonlocal started, usage, thread
        if usage is not None:
            if usage.uuids != {card['uuid']}:
                raise RuntimeError('图片服务显卡已变化，请核对后重试。')
            return
        started = time.monotonic()
        usage = UsageRecorder([card['uuid']])
        usage.capture()
        publish(gpu=card, gpus=[card], execution_started_at=time.time())

        def monitor():
            while not stop.wait(2):
                usage.capture()
                try:
                    check_cancel()
                except Cancelled:
                    publish(stage='正在取消 · 等待本次图片请求结束')
                else:
                    publish()
                (SERVICE / 'activity').touch()

        thread = threading.Thread(target=monitor, daemon=True)
        thread.start()
    try:
        publish()
        marker = json.loads(safe(folder / 'prepared.json', folder).read_text())
        if marker.get('id') != req['id'] or marker.get('token') != req['run_token'] or marker.get('request_sha256') != digest(folder / 'request.json'):
            raise ValueError('图片任务准备清单已变化。')
        images = verified_inputs(folder, req)
        control = load_control()
        lock = safe(SERVICE / 'request.lock', SERVICE).open('a')
        while True:
            check_cancel()
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
                break
            except BlockingIOError:
                publish(status='waiting', stage='排队中 · 等待其他图片请求完成')
                time.sleep(1)
        check_cancel()
        safe(lease, SERVICE)
        with lease.open('x') as stream:
            stream.write(req['run_token'])
        owns_lease = True
        card = acquire_service(control, publish, check_cancel, begin_usage)
        check_cancel()
        # Recheck ownership and foreign processes immediately before the HTTP request.
        card = service_card(control, control.status(), inventory())
        begin_usage(card)
        publish(status='running', stage='生成图片', generation_started_at=time.time())
        generated = time.monotonic()
        raw = image_request(control, req, images)
        generation_seconds = round(time.monotonic() - generated, 2)
        check_cancel()
        target = safe(folder / 'output' / 'H3_image.png', folder)
        with target.open('xb') as stream:
            stream.write(raw)
        checksum = hashlib.sha256(raw).hexdigest()
        if digest(target) != checksum:
            raise ValueError('图片结果 SHA-256 校验失败。')
        usage.capture()
        publish(status='completed', stage='图片已生成 · 等待保存到本地', generation_seconds=generation_seconds,
                results=[{'name': target.name, 'relative': target.name, 'size': len(raw), 'sha256': checksum}], finished_at=time.time())
    except Cancelled:
        publish(status='cancelled', stage='已取消', finished_at=time.time())
    except Exception as error:
        # Do not put service internals, HTTP response bodies, or prompt text in error output.
        message = str(error) if isinstance(error, (ValueError, RuntimeError)) else type(error).__name__
        publish(status='failed', stage='图片生成失败', error='图片任务失败：' + message[:600], finished_at=time.time())
    finally:
        stop.set()
        if thread:
            thread.join(timeout=15)
        if owns_lease and lease.exists() and not lease.is_symlink() and lease.read_text() == req['run_token']:
            lease.unlink()
            (SERVICE / 'activity').touch()
        if lock:
            lock.close()


if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == '--prepare':
        print(json.dumps(prepare_job(Path(sys.argv[2]))))
    elif len(sys.argv) == 2:
        run(Path(sys.argv[1]))
    else:
        raise SystemExit('用法：h3_image_worker.py [--prepare] TASK_FOLDER')
