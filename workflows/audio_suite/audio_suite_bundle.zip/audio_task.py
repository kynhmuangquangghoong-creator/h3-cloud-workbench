"""Submit a verified audio workflow to the independent 5090 ComfyUI instance.

Usage: python audio_task.py list | status | run MODE [options]
Credentials are read from the local GPU workbench DPAPI store and never printed.
"""
import argparse
import json
import os
import shlex
import socket
import sys
import time
import uuid
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
from remote_exec import STATE, load_connection, paramiko  # noqa: E402

REMOTE = PurePosixPath('/home/xuliangliang/workspaces/audio-ai')
PYTHON = str(REMOTE / 'venv/bin/python')
CLIENT = str(REMOTE / 'comfy_client.py')
MODES = {
    'ace-sft': ('ace15_xl_sft.api.json', 'ACE-Step XL SFT: prompt/tags, optional lyrics'),
    'ace-turbo': ('ace15_xl_turbo.api.json', 'ACE-Step XL Turbo: prompt/tags, optional lyrics'),
    'tts-design': ('tts_voice_design.api.json', 'Qwen3-TTS VoiceDesign: text + optional voice instruction'),
    'tts-clone': ('tts_voice_clone.api.json', 'Qwen3-TTS Base: text + reference audio'),
    'asr': ('asr_from_tts.api.json', 'Qwen3-ASR transcription: input audio'),
    'stems': ('demucs_stems.api.json', 'Demucs: separate vocals, bass, drums, other'),
    'yue2-music': ('yue2_text_to_music.api.json', 'YuE2 text to music: style + optional lyrics'),
    'yue2-cover': ('yue2_cover.api.json', 'YuE2 cover: style + reference music + optional lyrics'),
    'sfx': ('stable_audio3_sfx.api.json', 'Stable Audio 3 Small SFX: sound effect prompt'),
}
MODELS = {
    'ace-sft': 'ACE-Step 1.5 XL SFT', 'ace-turbo': 'ACE-Step 1.5 XL Turbo',
    'tts-design': 'Qwen3-TTS 1.7B VoiceDesign', 'tts-clone': 'Qwen3-TTS 1.7B Base',
    'asr': 'Qwen3-ASR 1.7B', 'stems': 'Demucs htdemucs',
    'yue2-music': 'YuE2-3B', 'yue2-cover': 'YuE2-3B',
    'sfx': 'Stable Audio 3 Small SFX',
}
AUDIO_MODES = {'tts-clone', 'asr', 'stems', 'yue2-cover'}
PROMPT_MODES = {'ace-sft', 'ace-turbo', 'yue2-music', 'yue2-cover', 'sfx'}
TEXT_MODES = {'tts-design', 'tts-clone'}
MAX_INPUT_BYTES = 200 * 1024 * 1024
MAX_OUTPUT_BYTES = 200 * 1024 * 1024
TASKS = ROOT / 'state' / 'tasks'


class GpuBusyError(RuntimeError):
    pass


def require_unshared_gpu(client, sftp, gpu_index):
    if gpu_index is None:
        raise GpuBusyError('无法确认音频服务使用的 GPU，任务未提交')
    try:
        with sftp.open(str(REMOTE / 'state/comfyui.pid'), 'rb') as f:
            own_pid = int(f.read().decode('ascii').strip())
    except (OSError, ValueError) as exc:
        raise GpuBusyError('无法确认音频服务进程，任务未提交') from exc
    code, out, _ = remote_command(
        client, f'nvidia-smi -i {gpu_index} --query-compute-apps=pid,process_name --format=csv,noheader', 20)
    if code:
        raise GpuBusyError(f'无法检查 GPU {gpu_index} 上的计算进程，任务未提交')
    other_pids = []
    for line in out.splitlines():
        pid_text = line.split(',', 1)[0].strip()
        if pid_text.isdigit() and int(pid_text) != own_pid:
            other_pids.append(pid_text)
    if other_pids:
        raise GpuBusyError(f'GPU {gpu_index} 已有其他计算进程（PID {", ".join(other_pids)}），任务未提交')


def record_task(run_id, **changes):
    """Persist a small local status record for the workbench UI."""
    TASKS.mkdir(parents=True, exist_ok=True)
    target = TASKS / f'{run_id}.json'
    data = json.loads(target.read_text(encoding='utf-8')) if target.exists() else {'id': run_id, 'created_at': time.time()}
    data.update(changes)
    data['updated_at'] = time.time()
    temporary = TASKS / f'.{run_id}.{os.getpid()}.tmp'
    temporary.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
    os.replace(temporary, target)


def connect():
    saved = load_connection()
    client = paramiko.SSHClient()
    client.load_host_keys(str(STATE / 'known_hosts'))
    client.set_missing_host_key_policy(paramiko.RejectPolicy())
    try:
        client.connect(
            hostname='5090-netmaker-100.119.106.8',
            sock=socket.create_connection(('127.0.0.1', 55090), timeout=12),
            username=saved['username'], password=saved['password'],
            look_for_keys=False, allow_agent=False, banner_timeout=12, auth_timeout=12,
        )
    except Exception:
        client.close()
        raise
    return client


def remote_command(client, command, timeout=60):
    _, out, err = client.exec_command(command, timeout=timeout)
    stdout = out.read().decode('utf-8', 'replace')
    stderr = err.read().decode('utf-8', 'replace')
    return out.channel.recv_exit_status(), stdout, stderr


def apply_options(wf, mode, args, reference_name=None):
    def set_input(node, key, value):
        if key not in wf[node]['inputs']:
            raise ValueError(f'{mode}: workflow node {node} has no {key}')
        wf[node]['inputs'][key] = value

    if args.prompt and mode not in PROMPT_MODES:
        raise ValueError(f'{mode} does not take --prompt')
    if args.text and mode not in TEXT_MODES:
        raise ValueError(f'{mode} does not take --text')
    if mode in PROMPT_MODES:
        if not args.prompt:
            raise ValueError(f'{mode} requires --prompt')
        node = '3' if mode == 'sfx' else '5' if mode in {'ace-sft', 'ace-turbo', 'yue2-cover'} else '2'
        set_input(node, 'text' if mode == 'sfx' else 'tags' if mode.startswith('ace-') else 'style', args.prompt)
    if mode in TEXT_MODES:
        if not args.text:
            raise ValueError(f'{mode} requires --text')
        set_input('1' if mode == 'tts-design' else '2', 'text', args.text)
    if args.reference_text is not None:
        if mode != 'tts-clone':
            raise ValueError('--reference-text applies only to tts-clone')
        set_input('2', 'reference_text', args.reference_text)
    if mode in AUDIO_MODES:
        if not args.input_audio:
            raise ValueError(f'{mode} requires --input-audio')
        if reference_name:
            set_input('1', 'audio', reference_name)
    elif args.input_audio:
        raise ValueError(f'{mode} does not take --input-audio')

    if args.lyrics_file and args.lyrics:
        raise ValueError('use --lyrics or --lyrics-file, not both')
    lyrics = Path(args.lyrics_file).read_text(encoding='utf-8') if args.lyrics_file else args.lyrics
    if mode in {'ace-sft', 'ace-turbo', 'yue2-music', 'yue2-cover'}:
        set_input('5' if mode != 'yue2-music' else '2', 'lyrics', lyrics or '')
    elif lyrics is not None:
        raise ValueError(f'{mode} does not take lyrics')

    if args.instruction is not None:
        if mode != 'tts-design':
            raise ValueError('--instruction applies only to tts-design')
        set_input('1', 'instruct', args.instruction)
    if args.language is not None:
        if mode == 'tts-design':
            set_input('1', 'language', args.language)
        elif mode == 'tts-clone':
            set_input('2', 'language', args.language)
        elif mode == 'asr':
            set_input('2', 'language', args.language)
        else:
            raise ValueError(f'{mode} does not take --language')
    if args.hints is not None:
        if mode != 'asr':
            raise ValueError('--hints applies only to asr')
        set_input('2', 'hints', args.hints)
    if args.duration is not None:
        if not 1 <= args.duration <= 120:
            raise ValueError('--duration must be between 1 and 120 seconds')
        if mode in {'ace-sft', 'ace-turbo'}:
            set_input('5', 'duration', args.duration)
            set_input('7', 'seconds', args.duration)
        elif mode in {'yue2-music', 'yue2-cover'}:
            set_input('2' if mode == 'yue2-music' else '5', 'max_duration', args.duration)
        elif mode == 'sfx':
            set_input('5', 'seconds', args.duration)
        else:
            raise ValueError(f'{mode} does not take --duration')
    if args.seed is not None:
        if not 0 <= args.seed <= 2**64 - 1:
            raise ValueError('--seed must be a nonnegative 64-bit integer')
        seed_nodes = {
            'ace-sft': ('5', '8'), 'ace-turbo': ('5', '8'), 'tts-design': ('1',),
            'tts-clone': ('2',), 'yue2-music': ('2', '5'), 'yue2-cover': ('5', '8'),
            'sfx': ('6',),
        }
        if mode not in seed_nodes:
            raise ValueError(f'{mode} does not take --seed')
        for node in seed_nodes[mode]:
            set_input(node, 'seed', args.seed)
    if args.plan_abc:
        if mode != 'yue2-music':
            raise ValueError('--plan-abc applies only to yue2-music')
        music = wf['2']['inputs']
        wf['8'] = {
            'class_type': 'YuE2GenerateABC',
            'inputs': {
                'clip': ['1', 1], 'style': music['style'], 'lyrics': music['lyrics'],
                'seed': music['seed'], 'mode': 'full', 'max_abc_tokens': 8192,
                'temperature': 0.7, 'top_p': 0.9, 'top_k': 30,
                'repetition_penalty': 1.005, 'penalty_window': 100,
            },
        }
        music['abc'] = ['8', 0]
    return wf


def get_workflow(mode, args, reference_name=None):
    path = ROOT / 'workflows' / MODES[mode][0]
    wf = json.loads(path.read_text(encoding='utf-8'))
    return apply_options(wf, mode, args, reference_name)


def run(args):
    mode = args.mode
    audio = None
    if args.input_audio:
        audio = Path(args.input_audio).expanduser().resolve(strict=True)
        if not audio.is_file() or audio.suffix.lower() not in {'.wav', '.flac', '.mp3'}:
            raise ValueError('reference audio must be a WAV, FLAC or MP3 file')
        if audio.stat().st_size > MAX_INPUT_BYTES:
            raise ValueError('reference audio exceeds 200 MiB')
    elif mode in AUDIO_MODES:
        raise ValueError(f'{mode} requires --input-audio')
    run_id = uuid.uuid4().hex
    reference_name = f'skill/{run_id}{audio.suffix.lower()}' if audio else None
    wf = get_workflow(mode, args, reference_name)
    if args.dry_run:
        print(json.dumps({'mode': mode, 'input_audio': str(audio) if audio else None, 'workflow': wf}, ensure_ascii=False, indent=2))
        return
    title = args.text or args.prompt or (f'{mode} · {audio.name}' if audio else mode)
    record_task(run_id, mode=mode, model=MODELS[mode],
                title=title[:160],
                input_audio=str(audio) if audio else None, status='running', files=[],
                params={'language': args.language, 'seed': args.seed,
                        'requested_duration_s': args.duration,
                        'plan_abc': args.plan_abc,
                        'reference_text': bool(args.reference_text),
                        'input_name': audio.name if audio else None})
    client = None
    try:
        client = connect()
        with client.open_sftp() as sftp:
            try:
                with sftp.open(str(REMOTE / 'state/comfyui.gpu'), 'rb') as f:
                    gpu_index = int(f.read().decode('ascii').strip())
            except (OSError, ValueError):
                gpu_index = None
            record_task(run_id, gpu_index=gpu_index)
            if args.require_idle_gpu:
                require_unshared_gpu(client, sftp, gpu_index)
            for folder in ('inputs/skill', 'tmp/skill'):
                path = str(REMOTE / folder)
                try:
                    sftp.stat(path)
                except FileNotFoundError:
                    sftp.mkdir(path)
            if audio:
                sftp.put(str(audio), str(REMOTE / 'inputs' / reference_name))
            remote_wf = str(REMOTE / 'tmp/skill' / f'{run_id}.json')
            with sftp.open(remote_wf, 'wb') as f:
                f.write(json.dumps(wf, ensure_ascii=False).encode('utf-8'))
            command = f'{shlex.quote(PYTHON)} {shlex.quote(CLIENT)} run {shlex.quote(remote_wf)} --out-dir {shlex.quote(str(REMOTE / "outputs/client"))} --timeout {args.timeout}'
            if gpu_index is not None:
                command += f' --track-gpu-index {gpu_index}'
            code, out, err = remote_command(client, command, args.timeout + 90)
            if code:
                raise RuntimeError((err + '\n' + out).strip()[-4000:] or f'remote exit {code}')
            result = json.loads(out)
            if not result.get('ok') or not result.get('prompt_id'):
                raise RuntimeError(f'unexpected remote result: {out[:1000]}')
            record_task(run_id, prompt_id=result['prompt_id'])
            base = REMOTE / 'outputs/client' / result['prompt_id']
            local_dir = Path(args.output_dir).expanduser().resolve() / mode / result['prompt_id']
            local_dir.mkdir(parents=True, exist_ok=True)
            copied = []
            for item in result.get('files', []):
                remote_path = PurePosixPath(item['local_path'])
                if remote_path.parent != base:
                    raise RuntimeError(f'unexpected output location: {remote_path}')
                size = sftp.stat(str(remote_path)).st_size
                if size > MAX_OUTPUT_BYTES:
                    raise RuntimeError(f'output exceeds 200 MiB: {remote_path.name}')
                dest = local_dir / remote_path.name
                sftp.get(str(remote_path), str(dest))
                copied.append(str(dest))
            record_task(run_id, status='completed', files=copied, elapsed_s=result.get('elapsed_s'),
                        gpu_usage=result.get('gpu_usage'))
            print(json.dumps({'ok': True, 'mode': mode, 'prompt_id': result['prompt_id'],
                              'elapsed_s': result.get('elapsed_s'), 'gpu_usage': result.get('gpu_usage'),
                              'files': copied}, ensure_ascii=False, indent=2))
    except Exception as exc:
        record_task(run_id, status='failed', error=str(exc) if isinstance(exc, GpuBusyError)
                    else '运行失败，请查看命令行输出')
        raise
    finally:
        if client:
            client.close()


def status():
    client = connect()
    try:
        with client.open_sftp() as sftp:
            with sftp.open(str(REMOTE / 'state/model_provenance.json'), 'rb') as f:
                data = json.loads(f.read().decode('utf-8'))
        code, out, err = remote_command(client, f'{shlex.quote(PYTHON)} {shlex.quote(CLIENT)} health', 25)
        health = json.loads(out) if code == 0 else {'error': (err or out)[-500:]}
        print(json.dumps({'comfyui_version': health.get('system', {}).get('comfyui_version'),
                          'models': {k: v.get('status') for k, v in sorted(data.items())}}, ensure_ascii=False, indent=2))
    finally:
        client.close()


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest='command', required=True)
    sub.add_parser('list', help='list available audio tasks')
    sub.add_parser('status', help='ComfyUI health and model download status')
    p = sub.add_parser('run', help='submit an audio task and copy its outputs locally')
    p.add_argument('mode', choices=MODES)
    p.add_argument('--prompt', help='music style/tags or sound effect description')
    p.add_argument('--text', help='TTS spoken text')
    p.add_argument('--instruction', help='TTS VoiceDesign voice description')
    p.add_argument('--lyrics', help='song lyrics; omitted means instrumental/empty lyrics')
    p.add_argument('--lyrics-file', help='UTF-8 text file containing song lyrics')
    p.add_argument('--plan-abc', action='store_true', help='YuE2: plan an original melody and chords before rendering')
    p.add_argument('--input-audio', help='local WAV, FLAC or MP3 reference')
    p.add_argument('--require-idle-gpu', action='store_true', help='opt in to refusing a GPU that hosts other compute processes')
    p.add_argument('--reference-text', help='exact transcript of reference audio for voice clone ICL mode')
    p.add_argument('--language', help='Qwen TTS/ASR language, e.g. Chinese or English')
    p.add_argument('--hints', help='Qwen ASR vocabulary hints')
    p.add_argument('--duration', type=float, help='requested audio duration in seconds (1-120)')
    p.add_argument('--seed', type=int, help='reproducible sampling seed')
    p.add_argument('--timeout', type=int, default=1800, help='remote run timeout in seconds')
    p.add_argument('--output-dir', default=str(ROOT / 'runs'), help='local output directory')
    p.add_argument('--dry-run', action='store_true', help='print the resolved workflow without remote actions')
    args = ap.parse_args()
    try:
        if args.command == 'list':
            for key, (_, description) in MODES.items():
                print(f'{key:12} {description}')
        elif args.command == 'status':
            status()
        else:
            if args.timeout < 1:
                raise ValueError('--timeout must be positive')
            run(args)
    except (OSError, ValueError, RuntimeError, paramiko.SSHException) as exc:
        print(f'error: {exc}', file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
