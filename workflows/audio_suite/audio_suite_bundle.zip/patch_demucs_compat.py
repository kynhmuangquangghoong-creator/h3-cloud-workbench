#!/usr/bin/env python3
"""Patch the isolated Demucs custom node for Torch 2.13 without system FFmpeg.

The old node wrote an AUDIO tensor to disk, then decoded the same file via
torchaudio. With torchaudio 2.11 that path requires FFmpeg shared libraries.
Demucs Separator already accepts a waveform tensor, so use it directly.
"""
from pathlib import Path

path = Path('/home/xuliangliang/workspaces/audio-ai/comfyui/custom_nodes/Demucs/Demucs_node.py')
src = path.read_text()
old = '''        torchaudio.save(file, audio["waveform"].squeeze(0), audio["sample_rate"])
        
        out=Path(folder_paths.get_output_directory())
        
        separated = model.separate_audio_file(file)[1]'''
new = '''        # ComfyUI has already decoded this AUDIO input. Avoid a redundant
        # torchaudio save/load roundtrip that requires system FFmpeg libs.
        out=Path(folder_paths.get_output_directory())

        separated = model.separate_tensor(
            audio["waveform"].squeeze(0).clone().float(), audio["sample_rate"]
        )[1]'''
if old in src:
    path.write_text(src.replace(old, new))
    print('patched', path)
elif new in src:
    print('already patched', path)
else:
    raise SystemExit('expected upstream block changed; refusing to patch')
