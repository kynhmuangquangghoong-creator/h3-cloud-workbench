#!/usr/bin/env python3
"""Remote-only ModelScope downloader for the audio-ai workspace. Run on the GPU node: $ROOT/venv/bin/python download_models.py -h"""
import argparse, hashlib, importlib.util, json, os, re, shutil, sys, time
from pathlib import Path

ROOT = Path(os.environ.get("AUDIO_AI_ROOT") or Path(__file__).resolve().parent)
MODELS, STATE, STAGE = ROOT / "comfyui" / "models", ROOT / "state", ROOT / "cache" / "stage"
PROV = STATE / "model_provenance.json"
MARGIN = 10 << 30
ACE = "Comfy-Org/ace_step_1.5_ComfyUI_files"


def snap(i, group, repo, dest, **kw):
    return dict(id=i, group=group, type="snapshot", repo=repo, dest=dest, default=kw.pop("default", True), **kw)


MANIFEST = [
    dict(id="ace15_xl_sft", group="ace-step", type="files", repo=ACE, default=True,
         files=[{"path": "diffusion_models/acestep_v1.5_xl_sft_bf16.safetensors"}]),
    dict(id="ace15_xl_turbo", group="ace-step", type="files", repo=ACE, default=True,
         files=[{"match": r"(^|/)diffusion_models/[^/]*xl[^/]*turbo[^/]*bf16[^/]*[.]safetensors$"}]),
    dict(id="ace15_lm4b_vae", group="ace-step", type="files", repo=ACE, default=True,
         files=[{"path": "text_encoders/qwen_0.6b_ace15.safetensors"},
                {"path": "text_encoders/qwen_4b_ace15.safetensors"}, {"path": "vae/ace_1.5_vae.safetensors"}]),
    snap("qwen3_tts_base", "qwen3-tts", "Qwen/Qwen3-TTS-12Hz-1.7B-Base", "qwen-voice/Qwen3-TTS-12Hz-1.7B-Base"),
    snap("qwen3_tts_voicedesign", "qwen3-tts", "Qwen/Qwen3-TTS-12Hz-1.7B-VoiceDesign", "qwen-voice/Qwen3-TTS-12Hz-1.7B-VoiceDesign"),
    snap("qwen3_tts_tokenizer", "qwen3-tts", "Qwen/Qwen3-TTS-Tokenizer-12Hz", "qwen-voice/Qwen3-TTS-Tokenizer-12Hz"),
    snap("qwen3_asr_1_7b_hf", "qwen3-asr", "Qwen/Qwen3-ASR-1.7B-hf", "Qwen3-ASR/Qwen3-ASR-1.7B-hf"),
    dict(id="yue2_comfy", group="yue2", type="files", repo="Comfy-Org/Yue2", default=True,
         files=[{"path": "checkpoints/yue2_3b_int8_convrot.safetensors"},
                {"path": "audio_encoders/sheetsage2_bf16.safetensors"}]),
    snap("yue2_official_3b", "yue2", "m-a-p/YuE2-3B", "yue2/YuE2-3B", default=False),
    snap("yue2_official_vae", "yue2", "m-a-p/YuE2-Vae", "yue2/YuE2-Vae", default=False),
    dict(id="demucs_htdemucs", group="demucs", type="runtime", module="demucs", model="htdemucs", dest="demucs", default=False),
    dict(id="stable_audio3_small_sfx", group="stable-audio", type="gated", source="hf-mirror.com (Comfy-Org official repack)",
         repo="Comfy-Org/stable-audio-3", default=True,
         reason="Requires user's acceptance of Stability AI/Gemma terms. Use download_stable_audio.sh after authorization; it verifies the official SHA256."),
]


def log(*a):
    print(time.strftime("%H:%M:%S"), *a, flush=True)


def sha256_file(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(8 << 20), b""):
            h.update(b)
    return h.hexdigest()


def safe(rel):
    p = Path(rel)
    if p.is_absolute() or ".." in p.parts:
        raise RuntimeError(f"unsafe path: {rel}")
    return p


def load_prov():
    return json.loads(PROV.read_text()) if PROV.exists() else {}


def save_prov(d):
    STATE.mkdir(parents=True, exist_ok=True)
    t = PROV.with_suffix(".tmp")
    t.write_text(json.dumps(d, indent=2, sort_keys=True))
    os.replace(t, PROV)


def file_rec(path, rel, **extra):
    st = path.stat()
    return dict(path=rel, size=st.st_size, mtime_ns=st.st_mtime_ns, sha256=sha256_file(path), **extra)


def intact(rec, path, deep):
    if not path.is_file() or path.stat().st_size != rec["size"]:
        return False
    return sha256_file(path) == rec["sha256"] if deep else path.stat().st_mtime_ns == rec["mtime_ns"]


def remote_files(repo):
    from modelscope.hub.api import HubApi
    return [f for f in HubApi().get_model_files(repo, recursive=True) if f.get("Type", "blob") == "blob"]


def resolve(entry, listing, selects):
    specs = list(entry.get("files", [])) + [{"match": m} for m in selects.get(entry["id"], [])]
    if entry.get("needs_select") and not specs:
        return None
    paths = {f["Path"]: f for f in listing}
    out = {}
    for s in specs:
        if "path" in s:
            hits = [p for p in paths if p == s["path"] or p.endswith("/" + s["path"])]
            if len(hits) != 1:
                raise RuntimeError(f"{entry['id']}: expected 1 remote file for {s['path']}, got {hits}")
        else:
            hits = [p for p in paths if re.search(s["match"], p)]
            if not hits:
                raise RuntimeError(f"{entry['id']}: no remote file matches {s['match']}")
        for p in hits:
            out[p] = (paths[p], s["path"] if "path" in s else re.sub(r"^split_files/", "", p))
    return list(out.values())


def fetch_file(repo, rel, dest):
    from modelscope.hub.file_download import model_file_download
    stage = STAGE / repo.replace("/", "__")
    stage.mkdir(parents=True, exist_ok=True)
    got = model_file_download(model_id=repo, file_path=rel, local_dir=str(stage))
    src = Path(got) if got and Path(got).is_file() else stage / rel
    if not src.is_file():
        raise RuntimeError(f"downloaded file not found under {stage}: {rel}")
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.move(str(src), str(dest))


def do_files(e, args, old):
    listing = remote_files(e["repo"])
    files = resolve(e, listing, args.select)
    if files is None:
        log(f"[{e['id']}] needs --select {e['id']}=REGEX; remote files of {e['repo']}:")
        for f in listing:
            print(f"  {f['Path']}  {f.get('Size')}")
        return dict(status="needs_selection")
    prev = {r["path"]: r for r in old.get("files", [])}
    recs, todo = [], []
    for f, rel in files:
        dest, rs = MODELS / e.get("prefix", "") / safe(rel), f.get("Sha256")
        r = prev.get(rel)
        if not r and not args.force and dest.is_file() and (sha256_file(dest) == rs if rs else dest.stat().st_size == f.get("Size")):
            r = file_rec(dest, rel, source_path=f["Path"], remote_sha256=rs)
        if r and not args.force and intact(r, dest, args.verify) and (not rs or r["sha256"] == rs):
            recs.append(r)
        else:
            todo.append((f, rel, dest))
    need = sum(f.get("Size") or 0 for f, _, _ in todo)
    if todo and not args.dry_run and need + MARGIN > shutil.disk_usage(ROOT).free:
        raise RuntimeError(f"insufficient disk: need ~{need >> 30} GiB plus margin")
    for f, rel, dest in todo:
        log(f"[{e['id']}] {'would download' if args.dry_run else 'downloading'} {f['Path']} ({f.get('Size')} bytes) -> {dest}")
        if args.dry_run:
            continue
        fetch_file(e["repo"], f["Path"], dest)
        r = file_rec(dest, rel, source_path=f["Path"], remote_sha256=f.get("Sha256"))
        if r["remote_sha256"] and r["sha256"] != r["remote_sha256"]:
            os.replace(dest, str(dest) + ".corrupt")
            raise RuntimeError(f"sha256 mismatch for {rel}; moved aside as .corrupt")
        recs.append(r)
    if args.dry_run:
        return dict(status="dry_run")
    keep = [r for p, r in prev.items() if p not in {rel for _, rel in files}]
    return dict(status="complete", files=recs + keep, skipped=not todo)


def do_snapshot(e, args, old):
    dest, prev = MODELS / safe(e["dest"]), old.get("files") or []
    if old.get("status") == "complete" and prev and not args.force and all(intact(r, dest / r["path"], args.verify) for r in prev):
        return dict(status="complete", files=prev, skipped=True)
    if not args.force and dest.is_dir():
        listing = [f for f in remote_files(e["repo"]) if not any(part.startswith(".") for part in Path(f["Path"]).parts)]
        if listing and all(isinstance(f.get("Size"), int) and (dest / safe(f["Path"])).is_file()
                           and (dest / safe(f["Path"])).stat().st_size == f["Size"] for f in listing):
            return dict(status="complete", files=[file_rec(dest / safe(f["Path"]), f["Path"]) for f in listing],
                        skipped=True)
    if args.dry_run:
        log(f"[{e['id']}] would snapshot_download {e['repo']} -> {dest}")
        return dict(status="dry_run")
    from modelscope import snapshot_download
    dest.mkdir(parents=True, exist_ok=True)
    kw = dict(model_id=e["repo"], local_dir=str(dest))
    try:
        snapshot_download(**kw, allow_patterns=e.get("allow_patterns"))
    except TypeError:
        snapshot_download(**kw, allow_file_pattern=e.get("allow_patterns"))
    pv, recs = {r["path"]: r for r in prev}, []
    for p in sorted(dest.rglob("*")):
        rel = p.relative_to(dest).as_posix()
        if p.is_file() and not any(x.startswith(".") for x in rel.split("/")):
            r = pv.get(rel)
            recs.append(r if r and intact(r, p, False) else file_rec(p, rel))
    if not recs:
        raise RuntimeError("snapshot produced no files")
    return dict(status="complete", files=recs)


def do_runtime(e, args, old):
    vendored = ROOT / "comfyui" / "custom_nodes" / "Demucs"
    if vendored.is_dir() and str(vendored) not in sys.path:
        sys.path.insert(0, str(vendored))
    if importlib.util.find_spec(e["module"]) is None:
        return dict(status="blocked", reason=f"module '{e['module']}' not installed in this venv; install after dependency review")
    if args.dry_run:
        return dict(status="dry_run")
    home = MODELS / safe(e["dest"]) / "torch"
    os.environ["TORCH_HOME"] = str(home)
    from demucs.pretrained import get_model
    get_model(e["model"])
    recs = [file_rec(p, p.relative_to(home).as_posix()) for p in sorted((home / "hub" / "checkpoints").glob("*")) if p.is_file()]
    if not recs:
        raise RuntimeError("no checkpoints found after get_model")
    return dict(status="complete", files=recs, note="downloaded by the official demucs runtime")


def do_gated(e, args, old):
    if old.get("status") == "complete" and old.get("files") and all(
        intact(r, MODELS / safe(r["path"]), args.verify) for r in old["files"]
    ):
        return dict(status="complete", files=old["files"], skipped=True)
    return dict(status="blocked", reason=e["reason"])


HANDLERS = dict(files=do_files, snapshot=do_snapshot, runtime=do_runtime, gated=do_gated)


def load_manifest(path):
    base = {e["id"]: e for e in MANIFEST}
    for e in json.loads(Path(path).read_text()) if path else []:
        base[e["id"]] = {**base.get(e["id"], {}), **e}
    return list(base.values())


def cmd_download(args, manifest):
    import modelscope
    sel = {}
    for s in args.select:
        k, sep, v = s.partition("=")
        if not sep:
            raise SystemExit(f"bad --select {s!r}; use ID=REGEX")
        sel.setdefault(k, []).append(v)
    args.select = sel
    unknown = (set(args.only or []) | set(sel)) - {e["id"] for e in manifest}
    if unknown:
        raise SystemExit(f"unknown ids: {sorted(unknown)}")
    chosen = [e for e in manifest if e["id"] in sel or (e["id"] in args.only if args.only else (e.get("group") in args.group if args.group else e.get("default")))]
    prov, rc = load_prov(), 0
    for e in chosen:
        eid, old = e["id"], prov.get(e["id"], {})
        if not args.dry_run:
            prov[eid] = {**old, "status": "downloading", "id": eid, "type": e["type"],
                         "repo": e.get("repo"), "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z")}
            save_prov(prov)
        for attempt in range(3):
            try:
                res = HANDLERS[e["type"]](e, args, old)
                break
            except RuntimeError as ex:
                res = dict(status="failed", error=str(ex))
                break
            except Exception as ex:
                res = dict(status="failed", error=f"{type(ex).__name__}: {ex}")
                if attempt < 2:
                    log(f"[{eid}] attempt {attempt + 1} failed: {res['error']}; retrying")
                    time.sleep(15 * 2 ** attempt)
        st = res["status"]
        log(f"[{eid}] {st}" + (" (up to date)" if res.get("skipped") else "") + (f": {res.get('error') or res.get('reason')}" if st in ("failed", "blocked") else ""))
        rc = max(rc, {"failed": 1, "needs_selection": 2}.get(st, 0))
        if st == "dry_run":
            continue
        now = time.strftime("%Y-%m-%dT%H:%M:%S%z")
        d = {**old, **{k: v for k, v in res.items() if k != "skipped"}, "id": eid, "type": e["type"], "source": e.get("source", "modelscope"),
             "repo": e.get("repo"), "revision": e.get("revision", "master"), "modelscope_version": modelscope.__version__, "updated_at": now}
        if st == "complete":
            d.pop("error", None)
            d.pop("reason", None)
            if not res.get("skipped"):
                d["downloaded_at"] = now
        prov[eid] = d
        save_prov(prov)
    return rc


def cmd_status(args, manifest):
    prov = load_prov()
    for e in manifest:
        p = prov.get(e["id"], {})
        size = sum(r["size"] for r in p.get("files", []))
        print(f"{e['id']:26} {p.get('status', 'not_downloaded'):16} files={len(p.get('files', [])):3} {size / 2**30:7.2f} GiB  {e.get('repo')}")
    return 0


def cmd_ls_repo(args, manifest):
    for f in remote_files(args.repo):
        print(f["Path"], f.get("Size"), (f.get("Sha256") or "")[:12])
    return 0


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--manifest", help="JSON list of extra/override manifest entries (merged by id)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    d = sub.add_parser("download", help="download selected manifest entries (resumable, idempotent)")
    d.add_argument("--only", nargs="+", metavar="ID")
    d.add_argument("--group", nargs="+")
    d.add_argument("--select", action="append", default=[], metavar="ID=REGEX", help="choose remote files by regex for needs_select entries (e.g. yue2_comfy)")
    d.add_argument("--verify", action="store_true", help="re-hash existing files instead of trusting size+mtime")
    d.add_argument("--force", action="store_true")
    d.add_argument("--dry-run", action="store_true")
    sub.add_parser("status", help="show provenance status of all manifest entries")
    r = sub.add_parser("ls-repo", help="list remote files of a ModelScope repo")
    r.add_argument("repo")
    args = ap.parse_args()
    if os.name != "posix" or not (ROOT / "comfyui").is_dir():
        raise SystemExit(f"refusing to run: {ROOT} is not the remote audio-ai workspace (downloads must run on the GPU node)")
    os.environ.setdefault("MODELSCOPE_CACHE", str(ROOT / "cache" / "modelscope"))
    os.environ["HF_HUB_OFFLINE"] = "1"
    fn = {"download": cmd_download, "status": cmd_status, "ls-repo": cmd_ls_repo}[args.cmd]
    manifest = load_manifest(args.manifest)
    if args.cmd != "download" or args.dry_run:
        return fn(args, manifest)
    import fcntl
    STATE.mkdir(parents=True, exist_ok=True)
    with (STATE / "model_provenance.lock").open("a+b") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        return fn(args, manifest)


if __name__ == "__main__":
    raise SystemExit(main())
